import type { ObjectExpression, QueryState } from '@actual-app/core/shared/query';
import type { WithRequired } from '@actual-app/core/types/util';
declare class Query {
    /** @type {import('@actual-app/core/shared/query').QueryState} */
    state: QueryState;
    constructor(state: WithRequired<Partial<QueryState>, 'table'>);
    filter(expr: ObjectExpression): Query;
    unfilter(exprs?: string[]): Query;
    select(exprs?: Array<ObjectExpression | string> | ObjectExpression | string | '*' | ['*']): Query;
    calculate(expr: ObjectExpression | string): Query;
    groupBy(exprs: ObjectExpression | string | Array<ObjectExpression | string>): Query;
    orderBy(exprs: ObjectExpression | string | Array<ObjectExpression | string>): Query;
    limit(num: number): Query;
    offset(num: number): Query;
    raw(): Query;
    withDead(): Query;
    withoutValidatedRefs(): Query;
    options(opts: Record<string, unknown>): Query;
    serialize(): QueryState;
    reset(): Query;
    serializeAsString(): string;
}
export declare function q(table: QueryState['table']): Query;
export {};
//# sourceMappingURL=query.d.ts.map